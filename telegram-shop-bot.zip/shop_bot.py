"""
Telegram Shop Bot - EKTA FILE EI SOB.
Direct purchase (kono wallet nei) + Supplier / Resell system.
bot.py + db.py + binance_pay.py + supplier.py - ek kore deoa hoyeche.
Sudhu ei 1 ta file + .env + requirements.txt lagbe.

Chalano:
  pip install -r requirements.txt
  python shop_bot.py
"""


# ================= Binance Pay =================
"""
Binance Pay Merchant API - auto top-up er jonno.
Official docs: https://developers.binance.com/docs/binance-pay/introduction
Base URL: https://bpay.binanceapi.com

Flow (SafwanTiger er moto shop gulo evabei kore):
1. Bot -> POST /binancepay/openapi/v3/order  (amount, merchantTradeNo)
   Binance firiye dey: checkoutUrl + prepayId
2. Customer checkoutUrl khule Binance app diye USDT pay kore
3. Bot "Check Payment" button e POST /binancepay/openapi/v2/order/query
   kore dekhe status == "PAID" kina
4. PAID hole wallet balance += amount

Webhook (aro advance): Binance Merchant dashboard e webhook URL bosale
Binance nije POST kore janay bizStatus=PAY_SUCCESS. Tokhon server ke
200 + "SUCCESS" firate hoy, signature RSA public key diye verify korte hoy.
Polling + Check button diye shuru kora shohoj, webhook pore add kora jay.

Auth: HMAC-SHA512
  signature = HMAC_SHA512(secret, timestamp + "\\n" + nonce + "\\n" + body + "\\n")
  headers: BinancePay-Timestamp, BinancePay-Nonce,
           BinancePay-Certificate-SN (= API Key), BinancePay-Signature
"""
import hashlib
import hmac
import json
import secrets
import time
import uuid

import requests

BASE_URL = "https://bpay.binanceapi.com"


class BinancePay:
    def __init__(self, api_key: str, api_secret: str):
        self.api_key = (api_key or "").strip()
        self.api_secret = (api_secret or "").strip()

    @property
    def configured(self) -> bool:
        return bool(self.api_key and self.api_secret)

    def _headers(self, body: str):
        timestamp = str(int(time.time() * 1000))
        nonce = secrets.token_hex(16)  # 32 char
        payload = f"{timestamp}\n{nonce}\n{body}\n"
        sig = hmac.new(
            self.api_secret.encode(),
            payload.encode(),
            hashlib.sha512,
        ).hexdigest().upper()
        return {
            "Content-Type": "application/json",
            "BinancePay-Timestamp": timestamp,
            "BinancePay-Nonce": nonce,
            "BinancePay-Certificate-SN": self.api_key,
            "BinancePay-Signature": sig,
        }

    def _post(self, path: str, data: dict):
        body = json.dumps(data, separators=(",", ":"))
        r = requests.post(
            BASE_URL + path, data=body, headers=self._headers(body), timeout=20
        )
        r.raise_for_status()
        return r.json()

    def create_order(self, amount: float, goods_name: str = "Wallet Top-up"):
        """Notun top-up order banay. Returns dict with checkoutUrl / prepayId."""
        merchant_trade_no = "TOP" + uuid.uuid4().hex[:16].upper()
        data = {
            "env": {"terminalType": "APP"},
            "merchantTradeNo": merchant_trade_no,
            "orderAmount": round(float(amount), 2),
            "currency": "USDT",
            "goods": {
                "goodsType": "01",
                "goodsCategory": "0000",
                "referenceGoodsId": merchant_trade_no,
                "goodsName": goods_name,
                "goodsDetail": "Wallet top-up",
            },
        }
        res = self._post("/binancepay/openapi/v3/order", data)
        # success: {"status":"SUCCESS","data":{"prepayId":..., "checkoutUrl":..., "deeplink":...}}
        if res.get("status") != "SUCCESS":
            raise RuntimeError(f"Binance Pay error: {res}")
        d = res["data"]
        d["merchantTradeNo"] = merchant_trade_no
        return d

    def query_order(self, merchant_trade_no: str):
        """Order er status janay. data.status: PAID / UNPAID / EXPIRED etc."""
        res = self._post(
            "/binancepay/openapi/v2/order/query",
            {"merchantTradeNo": merchant_trade_no},
        )
        if res.get("status") != "SUCCESS":
            raise RuntimeError(f"Binance Pay query error: {res}")
        return res["data"]


# ================= Supplier =================
"""
Supplier / Resell system.

2 rokom product:
- own: tumi nije banale / age theke stock kine rekhecho. Bot nijer stock theke dey.
- supplier: onno seller / onno bot theke kine tomar customer ke dite hobe.

FULL AUTO kobe hobe?
- Supplier jodi API dey (jemon onek panel / amader code diye banano bot e
  ekta choto API thake), taholei full auto hobe.
  Tomar bot supplier API ke bolbe: POST {api_key, product_id}
  Supplier tokhon 1 ta stock item firiye debe, tomar bot seta customer ke diye debe.
  Tomar lav = sell price - cost price.

- Supplier jodi sudhu Telegram bot hoy, kono API na dey,
  tahole Bot API diye full auto hobe NA. Karon:
  1. Telegram bot arek bot ke message korte pare na.
  2. Supplier bot er Binance checkout e manusher hate pay korte hoy.
  Tokhon system ta hobe SEMI-AUTO (niche dekh):
  Customer pay korle order PENDING thakbe, admin ke alert jabe,
  admin supplier bot theke kine /fulfill diye content pathale
  bot seta waiting customer ke auto pathiye debe.
  Ba age bulk e kine stock kore rakho - tokhon own er motoi auto cholbe.

Ei file er buy_from_supplier() sudhu API wala supplier er jonno.
"""
import requests


def buy_from_supplier(product):
    """Returns (ok, message, content).
    product is a sqlite Row with supplier_url, supplier_api_key,
    supplier_product_id, cost_price.
    Supplier API expected reply (jekono ekta format cholbe):
      {"status": "success", "content": "mail:pass"}
      {"status": "success", "item": "mail:pass"}
      {"content": "mail:pass"}
    """
    url = (product["supplier_url"] or "").strip() if "supplier_url" in product.keys() else ""
    if not url:
        return False, "Supplier API bosano nei", None
    try:
        r = requests.post(
            url,
            json={
                "api_key": product["supplier_api_key"],
                "product_id": product["supplier_product_id"],
                "quantity": 1,
            },
            timeout=30,
        )
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        return False, f"Supplier API error: {e}", None
    content = data.get("content") or data.get("item") or data.get("code") or data.get("account")
    if data.get("status") in ("success", "ok", "paid") or content:
        if content:
            return True, "Success", str(content)
    return False, f"Supplier dey ni: {data}", None


# ================= Database =================
"""SQLite database - user, product, stock, order, direct payment.

DIRECT PURCHASE - kono wallet / deposit / balance nei.
- Customer product e click kore, oi product er dam tai Binance Pay diye pay kore.
- Pay confirm hole bot stock theke 1 ta item dey.
Stock er asol khela ekhanei:
- Admin age theke product er stock add kore rakhe.
  Proti stock = 1 ta line, jemon: email:password  ba  ekta invite link.
- Customer kinle bot sobcheye purono UNUSED stock ta ney,
  status = USED kore dey, buyer ke pathiye dey.
  Tai ekta stock 2 jon pabe na, ar stock count auto 1 kombe.
  Amra row delete kori na, USED mark kori - pore hisab / refund er jonno.
"""
import sqlite3

DB_PATH = "shop.db"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT,
        balance REAL DEFAULT 0,
        email TEXT,
        referrer_id INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        description TEXT DEFAULT '',
        active INTEGER DEFAULT 1
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS stock (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        status TEXT DEFAULT 'unused',
        sold_to INTEGER,
        sold_at TEXT,
        FOREIGN KEY(product_id) REFERENCES products(id)
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        stock_id INTEGER,
        amount REAL NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    c.execute("""
    CREATE TABLE IF NOT EXISTS topups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        merchant_trade_no TEXT,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    # Direct purchase: kon product er jonno kon Binance order - pay check korar jonno
    c.execute("""
    CREATE TABLE IF NOT EXISTS pending_payments (
        merchant_trade_no TEXT PRIMARY KEY,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    # Supplier order: customer pay koreche, kintu supplier theke ekhono item aseni
    c.execute("""
    CREATE TABLE IF NOT EXISTS supplier_orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        merchant_trade_no TEXT,
        amount REAL NOT NULL,
        status TEXT DEFAULT 'pending',
        content TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")
    # Product er source: own / supplier. Purono DB te column na thakle add koro.
    for sql in [
        "ALTER TABLE products ADD COLUMN source TEXT DEFAULT 'own'",
        "ALTER TABLE products ADD COLUMN supplier_url TEXT DEFAULT ''",
        "ALTER TABLE products ADD COLUMN supplier_api_key TEXT DEFAULT ''",
        "ALTER TABLE products ADD COLUMN supplier_product_id TEXT DEFAULT ''",
        "ALTER TABLE products ADD COLUMN cost_price REAL DEFAULT 0",
    ]:
        try:
            c.execute(sql)
        except Exception:
            pass
    conn.commit()

    # Prothombar khali thakle sample product (stock 0, tai Shop e dekhabe kintu kinte parbe na
    # jotokkhon na tumi stock add koro)
    if c.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        c.executemany(
            "INSERT INTO products (name, price, description) VALUES (?,?,?)",
            [
                ("Gemini Pro 2 Years + YouTube 1M On Mail", 3.99, "On mail, full warranty"),
                ("ChatGPT Plus 1M (25DW)", 7.00, "Plus account, 25 days warranty"),
                ("CapCut Pro 1M", 2.50, "All plans, invite link"),
            ],
        )
        conn.commit()
    conn.close()


def ensure_user(user_id: int, username: str | None, referrer_id: int | None = None):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO users (id, username, referrer_id) VALUES (?,?,?)",
            (user_id, username, referrer_id),
        )
        conn.commit()
    conn.close()


def get_user(user_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    conn.close()
    return row


def add_balance(user_id: int, amount: float):
    conn = get_db()
    conn.execute("UPDATE users SET balance = balance + ? WHERE id=?", (amount, user_id))
    conn.commit()
    conn.close()


def stock_count(product_id: int) -> int:
    conn = get_db()
    n = conn.execute(
        "SELECT COUNT(*) FROM stock WHERE product_id=? AND status='unused'",
        (product_id,),
    ).fetchone()[0]
    conn.close()
    return n


def list_products(page: int = 0, per_page: int = 5):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM products WHERE active=1 ORDER BY id LIMIT ? OFFSET ?",
        (per_page, page * per_page),
    ).fetchall()
    total = conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
    conn.close()
    return rows, total


def get_product(product_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
    conn.close()
    return row


def create_pending_payment(merchant_trade_no: str, user_id: int, product_id: int, amount: float):
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO pending_payments (merchant_trade_no, user_id, product_id, amount) VALUES (?,?,?,?)",
        (merchant_trade_no, user_id, product_id, amount),
    )
    conn.commit()
    conn.close()


def get_pending_payment(merchant_trade_no: str):
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM pending_payments WHERE merchant_trade_no=?", (merchant_trade_no,)
    ).fetchone()
    conn.close()
    return row


def mark_pending_paid(merchant_trade_no: str):
    conn = get_db()
    conn.execute(
        "UPDATE pending_payments SET status='paid' WHERE merchant_trade_no=?",
        (merchant_trade_no,),
    )
    conn.commit()
    conn.close()


def deliver_product(user_id: int, product_id: int):
    """Pay confirm howar por 1 ta unused stock delivery dey. Kono balance kate na.
    Returns (ok, msg, stock_content)."""
    conn = get_db()
    try:
        conn.execute("BEGIN IMMEDIATE")
        prod = conn.execute("SELECT * FROM products WHERE id=?", (product_id,)).fetchone()
        if not prod:
            return False, "Product pawa jayni.", None
        stock = conn.execute(
            "SELECT * FROM stock WHERE product_id=? AND status='unused' ORDER BY id LIMIT 1",
            (product_id,),
        ).fetchone()
        if not stock:
            return False, "Ei product ekhon stock out. Pore try koro.", None
        conn.execute(
            "UPDATE stock SET status='used', sold_to=?, sold_at=CURRENT_TIMESTAMP WHERE id=?",
            (user_id, stock["id"]),
        )
        conn.execute(
            "INSERT INTO orders (user_id, product_id, stock_id, amount) VALUES (?,?,?,?)",
            (user_id, product_id, stock["id"], prod["price"]),
        )
        conn.commit()
        return True, "Success", stock["content"]
    except Exception as e:
        conn.rollback()
        return False, f"Error: {e}", None
    finally:
        conn.close()


# Purono naam - ekhon deliver_product kei dake, balance check kore na
def buy_product(user_id: int, product_id: int):
    return deliver_product(user_id, product_id)


def set_product_supplier(product_id: int, url: str, api_key: str, supplier_product_id: str, cost_price: float):
    conn = get_db()
    conn.execute(
        "UPDATE products SET source='supplier', supplier_url=?, supplier_api_key=?, supplier_product_id=?, cost_price=? WHERE id=?",
        (url, api_key, supplier_product_id, cost_price, product_id),
    )
    conn.commit()
    conn.close()


def create_supplier_order(user_id: int, product_id: int, merchant_trade_no: str, amount: float):
    conn = get_db()
    cur = conn.execute(
        "INSERT INTO supplier_orders (user_id, product_id, merchant_trade_no, amount) VALUES (?,?,?,?)",
        (user_id, product_id, merchant_trade_no, amount),
    )
    conn.commit()
    oid = cur.lastrowid
    conn.close()
    return oid


def fulfill_supplier_order(order_id: int, content: str):
    """Admin supplier theke kine content dile - order fulfilled mark koro, customer ke dite hobe."""
    conn = get_db()
    row = conn.execute("SELECT * FROM supplier_orders WHERE id=?", (order_id,)).fetchone()
    if not row:
        conn.close()
        return None
    conn.execute(
        "UPDATE supplier_orders SET status='fulfilled', content=? WHERE id=?",
        (content, order_id),
    )
    conn.execute(
        "INSERT INTO orders (user_id, product_id, stock_id, amount) VALUES (?,?,NULL,?)",
        (row["user_id"], row["product_id"], row["amount"]),
    )
    conn.commit()
    conn.close()
    return row


# ================= Bot =================
import os

from dotenv import load_dotenv
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)


load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "6847035633").split(",") if x.strip()}
SHOP_NAME = os.getenv("SHOP_NAME", "Dadu Premium Shop")
BOT_NAME = os.getenv("BOT_NAME", "Dadu Premium Shop")
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "")
CHANNEL_URL = os.getenv("CHANNEL_URL", "")
BINANCE_PAY_ID = os.getenv("BINANCE_PAY_ID", "")
REFER_BONUS_PERCENT = float(os.getenv("REFER_BONUS_PERCENT", "5"))
LOW_STOCK_ALERT = int(os.getenv("LOW_STOCK_ALERT", "3"))

bp = BinancePay(os.getenv("BINANCE_PAY_API_KEY", ""), os.getenv("BINANCE_PAY_API_SECRET", ""))

PER_PAGE = 5


def main_menu(balance: float = 0):
    # balance arg ekhon ar use hoy na - direct purchase, kono wallet nei
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍️ Shop", callback_data="shop:0")],
        [InlineKeyboardButton("⚙️ Settings", callback_data="settings")],
        [
            InlineKeyboardButton("🆘 Support", callback_data="support"),
            InlineKeyboardButton("🤖 Kiwi Ai", callback_data="ai"),
        ],
        [
            InlineKeyboardButton("⭐ Refer", callback_data="refer"),
            InlineKeyboardButton("📢 Channel", url=CHANNEL_URL) if CHANNEL_URL else
            InlineKeyboardButton("📢 Channel", callback_data="channel"),
        ],
    ])


def admin_menu():
    """Telegram Admin Panel - button diye sob kaj."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Add Product", callback_data="admin_add_product")],
        [InlineKeyboardButton("📦 Add Stock", callback_data="admin_add_stock")],
        [InlineKeyboardButton("📋 Products & Stock", callback_data="admin_products")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="menu")],
    ])


def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS


async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    referrer = None
    if ctx.args:
        try:
            referrer = int(ctx.args[0].replace("ref", ""))
            if referrer == user.id:
                referrer = None
        except ValueError:
            pass
    ensure_user(user.id, user.username, referrer)
    u = get_user(user.id)
    text = f"👋 Welcome to {BOT_NAME}!\n\nShop theke product beche nao, pay korlei sathe sathe peye jabe."
    await update.message.reply_text(text, reply_markup=main_menu())


async def show_shop(update: Update, ctx: ContextTypes.DEFAULT_TYPE, page: int):
    q = update.callback_query
    products, total = list_products(page, PER_PAGE)
    pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    if not products:
        await q.edit_message_text("Ekhon kono product nei.", reply_markup=main_menu())
        return
    lines = ["Available Products:\n"]
    kb = []
    for p in products:
        stock = stock_count(p["id"])
        lines.append(f"{p['name']} - {p['price']:.2f} USDT (Stock: {stock})")
        kb.append([InlineKeyboardButton(
            f"{p['name']} - {p['price']:.2f} USDT (Stock: {stock})",
            callback_data=f"buy:{p['id']}",
        )])
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Back", callback_data=f"shop:{page-1}"))
    nav.append(InlineKeyboardButton(f"{page+1}/{pages}", callback_data="noop"))
    if page + 1 < pages:
        nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"shop:{page+1}"))
    kb.append(nav)
    kb.append([InlineKeyboardButton("🔄 Refresh", callback_data=f"shop:{page}")])
    kb.append([InlineKeyboardButton("⬅️ Back to Menu", callback_data="menu")])
    await q.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(kb))


async def show_admin_products(q, ctx):
    """Admin ke product + stock list dekhay, kom stock e ⚠️ dey."""
    products, _ = list_products(0, 100)
    if not products:
        await q.edit_message_text("Kono product nei. Age Add Product koro.", reply_markup=admin_menu())
        return
    lines = ["📋 Products & Stock:\n"]
    kb = []
    for p in products:
        stock = stock_count(p["id"])
        warn = " ⚠️ LOW" if stock <= LOW_STOCK_ALERT else ""
        lines.append(f"#{p['id']} {p['name']} - ${p['price']:.2f} (Stock: {stock}{warn})")
        kb.append([InlineKeyboardButton(
            f"📦 Stock add: {p['name']} ({stock})",
            callback_data=f"admin_stock_pick:{p['id']}",
        )])
    kb.append([InlineKeyboardButton("⬅️ Admin Panel", callback_data="admin_panel")])
    await q.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(kb))


async def on_button(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data
    user = update.effective_user
    ensure_user(user.id, user.username)
    u = get_user(user.id)

    # ---------- Admin Panel buttons (sudhu admin) ----------
    if data.startswith("admin_"):
        if not is_admin(user.id):
            await q.answer("Tumi admin na.", show_alert=True)
            return
        if data == "admin_panel":
            await q.edit_message_text("🛠 Admin Panel\n\nButton e tap kore kaj koro.", reply_markup=admin_menu())
        elif data == "admin_add_product":
            ctx.user_data["state"] = "admin_product_name"
            await q.edit_message_text(
                "➕ Notun Product\n\nStep 1/3: Product er naam pathao.\nJemon: Gemini Pro 2 Years",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Admin Panel", callback_data="admin_panel")]]),
            )
        elif data == "admin_add_stock":
            products, _ = list_products(0, 100)
            if not products:
                await q.edit_message_text("Age ekta product add koro.", reply_markup=admin_menu())
                return
            kb = [[InlineKeyboardButton(f"{p['name']} (Stock: {stock_count(p['id'])})", callback_data=f"admin_stock_pick:{p['id']}")] for p in products]
            kb.append([InlineKeyboardButton("⬅️ Admin Panel", callback_data="admin_panel")])
            await q.edit_message_text("📦 Kon product e stock add korba? Product ta tap koro:", reply_markup=InlineKeyboardMarkup(kb))
        elif data.startswith("admin_stock_pick:"):
            pid = int(data.split(":")[1])
            p = get_product(pid)
            ctx.user_data["state"] = "add_stock"
            ctx.user_data["add_stock_pid"] = pid
            await q.edit_message_text(
                f"📦 {p['name']} - ekhon stock {stock_count(pid)} ta\n\n"
                "Stock gulo pathao. Proti line e 1 ta kore, jemon:\n"
                "email:password\nba\nhttps://link...",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Admin Panel", callback_data="admin_panel")]]),
            )
        elif data == "admin_products":
            await show_admin_products(q, ctx)
        return

    if data == "menu":
        await q.edit_message_text(
            f"👋 Welcome to {BOT_NAME}!\n\nShop theke product beche nao, pay korlei sathe sathe peye jabe.",
            reply_markup=main_menu(),
        )
    elif data == "noop":
        return
    elif data.startswith("shop:"):
        await show_shop(update, ctx, int(data.split(":")[1]))
    elif data.startswith("buy:"):
        pid = int(data.split(":")[1])
        p = get_product(pid)
        if not p:
            await q.answer("Product pawa jayni.", show_alert=True)
            return
        stock = stock_count(pid)
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton(f"💳 Buy Now - ${p['price']:.2f} - Pay with Binance", callback_data=f"pay:{pid}")],
            [InlineKeyboardButton("⬅️ Back", callback_data="shop:0")],
        ])
        await q.edit_message_text(
            f"{p['name']}\n\nPrice: ${p['price']:.2f} USDT\nStock: {stock}\n\n{p['description']}",
            reply_markup=kb,
        )
    elif data.startswith("pay:"):
        pid = int(data.split(":")[1])
        p = get_product(pid)
        if not p:
            await q.answer("Product pawa jayni.", show_alert=True)
            return
        if stock_count(pid) == 0:
            await q.edit_message_text("❌ Ei product ekhon stock out.", reply_markup=main_menu())
            return
        if not bp.configured:
            await q.edit_message_text("❌ Binance Pay API bosano nei. Admin ke janao.", reply_markup=main_menu())
            return
        try:
            order = bp.create_order(p["price"], goods_name=p["name"])
        except Exception as e:
            await q.edit_message_text(f"❌ Binance order banate parini: {e}", reply_markup=main_menu())
            return
        create_pending_payment(order["merchantTradeNo"], user.id, pid, p["price"])
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 Pay with Binance", url=order["checkoutUrl"])],
            [InlineKeyboardButton("✅ I Paid - Check Payment", callback_data=f"checkpay:{order['merchantTradeNo']}")],
            [InlineKeyboardButton("⬅️ Back", callback_data="menu")],
        ])
        await q.edit_message_text(
            f"""💳 {p['name']}

Price: ${p['price']:.2f} USDT

Pay with Binance button e tap kore pay koro, tarpor 'I Paid - Check Payment' e tap koro. Pay confirm holei product sathe sathe peye jabe. Kono deposit / wallet lagbe na.""",
            reply_markup=kb,
        )
    elif data.startswith("checkpay:"):
        trade_no = data.split(":")[1]
        pending = get_pending_payment(trade_no)
        if not pending:
            await q.answer("Order pawa jayni.", show_alert=True)
            return
        if pending["status"] == "paid":
            await q.answer("Ei order ta agei paid hoyeche.", show_alert=True)
            return
        if not bp.configured:
            await q.answer("Binance Pay API bosano nei, admin ke janao.", show_alert=True)
            return
        try:
            res = bp.query_order(trade_no)
        except Exception as e:
            await q.answer(f"Check korte parini: {e}", show_alert=True)
            return
        if res.get("status") == "PAID":
            mark_pending_paid(trade_no)
            p = get_product(pending["product_id"])
            # Supplier product? Age supplier API theke kenar try koro.
            if p["source"] == "supplier":
                ok_s, msg_s, content_s = buy_from_supplier(p)
                if ok_s:
                    create_supplier_order(user.id, p["id"], trade_no, p["price"])
                    await q.edit_message_text(
                        f"""✅ Payment Successful!

{p['name']} - ${p['price']:.2f}

🎁 Your product:
`{content_s}`

Dhonnobad! Kono somossa hole Support e janio.""",
                        parse_mode="Markdown",
                        reply_markup=main_menu(),
                    )
                    return
                # API nei / fail - semi-auto: order pending rakho, admin ke janao
                oid = create_supplier_order(user.id, p["id"], trade_no, p["price"])
                for aid in ADMIN_IDS:
                    try:
                        await ctx.bot.send_message(
                            aid,
                            f"""🔔 Supplier Order #{oid}
Customer: {user.id} (@{user.username})
Product: {p['name']} - ${p['price']:.2f} - PAID
Supplier API theke auto aseni: {msg_s}

Supplier bot theke kine content ta pathate:
/fulfill {oid}
tarpor product er line ta pathao, bot customer ke diye debe.""",
                        )
                    except Exception:
                        pass
                await q.edit_message_text(
                    f"""✅ Payment Successful!

{p['name']} - ${p['price']:.2f}

Tomar payment confirm hoyeche. Ei product supplier theke ana hocche, 5-10 min er moddhe product ta ekhanei peye jabe.""",
                    reply_markup=main_menu(),
                )
                return
            ok, msg, content = deliver_product(user.id, pending["product_id"])
            if not ok:
                await q.edit_message_text(f"✅ Payment hoyeche, kintu {msg} Admin ke janao.", reply_markup=main_menu())
                return
            left = stock_count(pending["product_id"])
            if left <= LOW_STOCK_ALERT:
                for aid in ADMIN_IDS:
                    try:
                        await ctx.bot.send_message(aid, f"""⚠️ Low Stock!
{p['name']}
Stock baki: {left} ta
/admin e giye stock add koro.""")
                    except Exception:
                        pass
            await q.edit_message_text(
                f"""✅ Payment Successful!

{p['name']} - ${p['price']:.2f}

🎁 Your product:
`{content}`

Dhonnobad! Kono somossa hole Support e janio.""",
                parse_mode="Markdown",
                reply_markup=main_menu(),
            )
        else:
            await q.answer(f"Ekhono pay hoyni. Status: {res.get('status')}", show_alert=True)
    elif data == "settings":
        ctx.user_data["state"] = "set_email"
        await q.edit_message_text(
            "📧 Please Add Your Verified Email for More Secured Experience\n\n"
            "Tomar email ta pathao. Eta diye order / support e help hobe.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data="menu")]]),
        )
    elif data == "support":
        txt = "🆘 Support\n\nKono somossa hole admin ke message dao."
        if SUPPORT_USERNAME:
            txt += f"\n\n@{SUPPORT_USERNAME}"
        await q.edit_message_text(txt, reply_markup=main_menu())
    elif data == "ai":
        await q.edit_message_text(
            "🤖 Kiwi Ai\n\nAmi ekhono shikhtechi. Product / price niye prosno thakle Support e jao.",
            reply_markup=main_menu(),
        )
    elif data == "refer":
        link = f"https://t.me/{ctx.bot.username}?start=ref{user.id}"
        await q.edit_message_text(
            f"⭐ Refer & Earn\n\nTomar link:\n{link}\n\n"
            "Tomar link diye keu asle tumi jante parba.",
            reply_markup=main_menu(),
        )
    elif data == "channel":
        await q.edit_message_text("📢 Channel link ekhono bosano hoyni.", reply_markup=main_menu())


async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = (update.message.text or "").strip()
    state = ctx.user_data.get("state")

    # --- Admin: Supplier order fulfill - supplier theke kena content pathale ---
    if state == "fulfill_order":
        if not is_admin(user.id):
            ctx.user_data["state"] = None
            return
        oid = ctx.user_data.get("fulfill_oid")
        ctx.user_data["state"] = None
        row = fulfill_supplier_order(oid, text)
        if not row:
            await update.message.reply_text("Order pawa jayni.")
            return
        p = get_product(row["product_id"])
        await update.message.reply_text(f"✅ Order #{oid} fulfill hoyeche. Customer ke product pathano hoyeche.")
        try:
            await ctx.bot.send_message(
                row["user_id"],
                f"""🎁 Tomar product eshe geche!

{p['name']}

`{text}`""",
                parse_mode="Markdown",
            )
        except Exception:
            pass
        return

    # --- Admin: Add Product - step by step ---
    if state == "admin_product_name":
        ctx.user_data["new_product_name"] = text
        ctx.user_data["state"] = "admin_product_price"
        await update.message.reply_text("Step 2/3: Price koto USDT? Sudhu number dao, jemon: 3.99")
        return
    if state == "admin_product_price":
        try:
            price = float(text)
            assert price > 0
        except (ValueError, AssertionError):
            await update.message.reply_text("Sothik price dao, jemon: 3.99")
            return
        ctx.user_data["new_product_price"] = price
        ctx.user_data["state"] = "admin_product_desc"
        await update.message.reply_text("Step 3/3: Description dao, ba 'skip' likho.")
        return
    if state == "admin_product_desc":
        name = ctx.user_data.get("new_product_name")
        price = ctx.user_data.get("new_product_price")
        desc = "" if text.lower() == "skip" else text
        ctx.user_data["state"] = None
        conn = get_db()
        cur = conn.execute("INSERT INTO products (name, price, description) VALUES (?,?,?)", (name, price, desc))
        conn.commit()
        pid = cur.lastrowid
        conn.close()
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📦 Ekhon Stock Add Koro", callback_data=f"admin_stock_pick:{pid}")],
            [InlineKeyboardButton("⬅️ Admin Panel", callback_data="admin_panel")],
        ])
        await update.message.reply_text(f"✅ Product add hoyeche!\n#{pid} {name} - ${price:.2f}", reply_markup=kb)
        return

    # --- Admin: stock add korar porer message ---
    if state == "add_stock":
        pid = ctx.user_data.get("add_stock_pid")
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        conn = get_db()
        conn.executemany("INSERT INTO stock (product_id, content) VALUES (?,?)", [(pid, l) for l in lines])
        conn.commit()
        conn.close()
        ctx.user_data["state"] = None
        p = get_product(pid)
        await update.message.reply_text(
            f"✅ {len(lines)} ta stock add hoyeche.\n{p['name']} - ekhon total stock: {stock_count(pid)} ta",
            reply_markup=admin_menu(),
        )
        return

    if state == "set_email":
        ctx.user_data["state"] = None
        conn = get_db()
        conn.execute("UPDATE users SET email=? WHERE id=?", (text, user.id))
        conn.commit()
        conn.close()
        await update.message.reply_text(f"✅ Email save hoyeche: {text}")
        return

    await update.message.reply_text("Menu dekhte /start dao.")


# ---------- Admin commands (purono system, ekhono cholbe) ----------
async def admin_panel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Tumi admin na. Admin Panel shudhu admin er jonno.")
        return
    await update.message.reply_text("🛠 Admin Panel\n\nButton e tap kore kaj koro.", reply_markup=admin_menu())


async def add_product(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    try:
        parts = update.message.text.split(" ", 1)[1].split("|")
        name, price, desc = parts[0].strip(), float(parts[1]), (parts[2].strip() if len(parts) > 2 else "")
    except Exception:
        await update.message.reply_text("Format: /addproduct Gemini Pro | 3.99 | On mail")
        return
    conn = get_db()
    cur = conn.execute("INSERT INTO products (name, price, description) VALUES (?,?,?)", (name, price, desc))
    conn.commit()
    pid = cur.lastrowid
    conn.close()
    await update.message.reply_text(f"✅ Product add hoyeche. ID: {pid}\nEkhon stock add koro: /addstock {pid}")


async def add_stock_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    try:
        pid = int(ctx.args[0])
    except (IndexError, ValueError):
        await update.message.reply_text("Format: /addstock 1")
        return
    ctx.user_data["state"] = "add_stock"
    ctx.user_data["add_stock_pid"] = pid
    await update.message.reply_text(f"Product #{pid} er stock pathao. Proti line e 1 ta kore, jemon:\nemail:password\nba\nhttps://link...")


async def list_products_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    products, _ = list_products(0, 100)
    lines = []
    for p in products:
        lines.append(f"#{p['id']} {p['name']} - ${p['price']:.2f} (Stock: {stock_count(p['id'])})")
    await update.message.reply_text("\n".join(lines) or "Kono product nei.")


async def set_supplier(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Ekta product ke supplier product banao.
    Format: /setsupplier <product_id> <supplier_api_url> <api_key> <supplier_product_id> <cost_price>
    Jemon: /setsupplier 2 https://example.com/api/buy KEY123 gemini-pro 2.50
    API na thakle url hisebe 'manual' dao - tokhon semi-auto cholbe."""
    if not is_admin(update.effective_user.id):
        return
    try:
        pid = int(ctx.args[0])
        url = ctx.args[1]
        api_key = ctx.args[2] if len(ctx.args) > 2 else ""
        spid = ctx.args[3] if len(ctx.args) > 3 else ""
        cost = float(ctx.args[4]) if len(ctx.args) > 4 else 0
    except (IndexError, ValueError):
        await update.message.reply_text("Format: /setsupplier <product_id> <api_url/manual> <api_key> <supplier_product_id> <cost_price>")
        return
    if url.lower() == "manual":
        url = ""
    set_product_supplier(pid, url, api_key, spid, cost)
    p = get_product(pid)
    await update.message.reply_text(
        f"✅ {p['name']} ekhon SUPPLIER product.\nSell: ${p['price']:.2f}, Cost: ${cost:.2f}, Lav: ${p['price']-cost:.2f}\n"
        + ("API diye full auto cholbe." if url else "API nei - semi-auto cholbe, pay hole admin ke alert jabe, /fulfill diye dite hobe.")
    )


async def fulfill_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    try:
        oid = int(ctx.args[0])
    except (IndexError, ValueError):
        await update.message.reply_text("Format: /fulfill <order_id>")
        return
    ctx.user_data["state"] = "fulfill_order"
    ctx.user_data["fulfill_oid"] = oid
    await update.message.reply_text(f"Order #{oid} er product content ta pathao (1 ta line).")


def main():
    init_db()
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN nei. .env file e BOT_TOKEN boshao.")
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("addproduct", add_product))
    app.add_handler(CommandHandler("addstock", add_stock_cmd))
    app.add_handler(CommandHandler("products", list_products_cmd))
    app.add_handler(CommandHandler("setsupplier", set_supplier))
    app.add_handler(CommandHandler("fulfill", fulfill_cmd))
    app.add_handler(CallbackQueryHandler(on_button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    print(f"{BOT_NAME} bot cholche...")
    app.run_polling()


if __name__ == "__main__":
    main()

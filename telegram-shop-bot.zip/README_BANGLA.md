# Telegram Shop Bot - Setup Guide (Phone diyei hobe)
## EKTA FILE EI SOB - shop_bot.py

## Notun system: DIRECT PURCHASE - kono wallet / deposit nei

Age wallet system chilo, ekhon seta tule deoa hoyeche. Ekhon flow ta emon:

**Customer:** Shop e product e click korbe -> Buy Now e tap korbe -> oi product er dam tai Binance Pay diye pay korbe -> bot auto check kore PAID hole sathe sathe product diye debe.

Age theke bot e taka joma rakhte hobe na, balance add korte hobe na.

## Vitore ki ache

**1. Bot er pechone 3 ta jinish:**
- Telegram Bot (@BotFather) - sudhu chat er mukh
- Python code (shop_bot.py - ekta file ei sob)
- Database (shop.db, SQLite) - user, product, stock, order sob ekhane

**2. Direct pay + auto-verify kivabe hoy:**
- Customer Buy Now tap korle bot Binance Pay Merchant API ke bole: `POST /binancepay/openapi/v3/order` - amount = oi product er dam
- Binance ekta `checkoutUrl` dey. Customer oi link e giye Binance app diye pay kore.
- Bot `I Paid - Check Payment` e `POST /binancepay/openapi/v2/order/query` kore dekhe status `PAID` kina.
- PAID holei product delivery hoy. Manush ke check korte hoy na.
- Eta korte Binance Merchant account lage: merchant.binance.com -> API Management -> API Key + Secret.

**3. Product auto-delivery:**
- Nijer product: tumi age stock add kore rakho, proti stock = 1 line (email:password ba link). Pay hole bot sobcheye purono UNUSED stock ta ney, USED mark kore, shudhu oi buyer ke dey. Stock auto 1 kome.
- Tai ekta account 2 jon pabe na.

## Supplier / Resell system - onno bot theke kine sell kora

Tumar 2 rokom product thakte pare:
- **Own:** tumi nije banale / age kine stock kore rekhecho
- **Supplier:** onno seller er bot theke kine tomar customer ke dite hobe

**Full auto kobe hobe?**
Supplier jodi API dey, taholei full auto hobe. Tomar bot supplier API ke bolbe, supplier 1 ta item firiye debe, tomar bot seta customer ke diye debe. Lav = sell price - cost price.

**Supplier sudhu Telegram bot hole, API na dile?**
Tokhon Bot API diye full auto hobe NA. Karon bot arek bot ke message korte pare na, ar supplier er Binance checkout e manusher hate pay korte hoy.
Tokhon ei bot e SEMI-AUTO cholbe:
- Customer pay korle order PENDING thakbe, tomake alert jabe
- Tumi supplier bot theke kine `/fulfill <order_id>` likhe content ta pathale bot waiting customer ke auto diye debe
- Ba age bulk e kine stock kore rakho - tokhon own er motoi full auto cholbe

**Supplier product banate:**
1. Age /admin -> Add Product diye product banao (sell price dao)
2. Tarpor bot e likho:
`/setsupplier <product_id> <api_url/manual> <api_key> <supplier_product_id> <cost_price>`
Jemon API thakle: `/setsupplier 2 https://supplier.example.com/api/buy KEY123 gemini-pro 2.50`
API na thakle: `/setsupplier 2 manual x x 2.50`

## Phone diye setup - 5 step

**Step 1 - Bot banao:** @BotFather -> /newbot -> naam + username dao -> token copy koro.
**Step 2 - Admin ID:** @userinfobot -> /start -> ID copy koro, `.env` e `ADMIN_IDS=123456789` boshao.
**Step 3 - Hosting (bot 24h cholte server lagbe):** Render.com e New Web Service -> GitHub e folder upload kore connect koro -> Environment Variables boshao -> Start Command: `python shop_bot.py`
**Step 4 - .env boshao:** `.env.example` copy kore `.env` banao, BOT_TOKEN, ADMIN_IDS, SHOP_NAME, BINANCE_PAY_API_KEY / SECRET boshao. API Key/Secret kauke dio na, chat e pathio na.
**Step 5 - Product add koro (/admin):**
- ➕ Add Product - naam, price, description - 3 step e
- 📦 Add Stock - product tap kore stock line pathao
- 📋 Products & Stock - stock koto ache dekho, kom hole ⚠️ LOW dekhabe
- Stock komle bot nijei janabe: "⚠️ Low Stock! Gemini Pro - Stock baki: 2 ta"

Bas, dokan chalu. Customer /start -> Shop -> product e click -> pay -> product auto pabe.

## Joruri sotorkota
- BOT_TOKEN, API Secret kauke dio na.
- shop.db backup rekho.
- Supplier er bot jodi API na dey, tahole keu jodi "bot diye bot theke auto kinbo" bole - seta sotti na, Binance pay er step e manush lagbei. Semi-auto ba age stock kine rakha - ei 2 tai safe rasta.
